import rightarrow from './rightarrow.svg'

export const assets = {
    rightarrow
}