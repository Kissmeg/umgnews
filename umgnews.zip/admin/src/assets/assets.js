import addimage from './addimage.svg'
import trashcan from './trashcan.svg'
export const assets = {
    addimage,
    trashcan,
}