import React from 'react'

const DeleteArticle = () => {
  return (
    <div>
      
    </div>
  )
}

export default DeleteArticle
