import rightarrow from './rightarrow.svg'
import loading from './loading.svg'
import menu from './menu.svg'
import logo from './logo.jpg'
import trashcan from './trashcan.svg'

export const assets = {
    trashcan,
    rightarrow,
    logo,
    menu,
    loading,
}